var nombre = prompt('Por favor, ingresá tu nombre: ')
var apellido = prompt('Por favor, ingresá tu apellido: ')

alert("Bienvenido a nuestro sitio web " + nombre + " " + apellido)