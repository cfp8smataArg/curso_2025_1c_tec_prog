//implementacion externa
alert('Esto es una implementación externa de JS')