function sumar(){
    var nro1=parseFloat(document.getElementById("numero1").value)
    var nro2=parseFloat(document.getElementById("numero2").value)
    var resultado_suma = nro1 + nro2
    document.getElementById("resultado").value = resultado_suma
}

function restar(){
    var nro1=parseFloat(document.getElementById("numero1").value)
    var nro2=parseFloat(document.getElementById("numero2").value)
    var resultado_resta = nro1 - nro2
    document.getElementById("resultado").value = resultado_resta
}

function multiplicar(){
        var nro1=parseFloat(document.getElementById("numero1").value)
    var nro2=parseFloat(document.getElementById("numero2").value)
    var resultado_mult = nro1 * nro2
    document.getElementById("resultado").value = resultado_mult
}

function dividir(){
    var nro1=parseFloat(document.getElementById("numero1").value)
    var nro2=parseFloat(document.getElementById("numero2").value)
    if(nro2!=0){
        var resultado_div = nro1 / nro2
        document.getElementById("resultado").value = resultado_div
    }else{
        document.getElementById("resultado").value = "Error / 0 !"
    }
    
}